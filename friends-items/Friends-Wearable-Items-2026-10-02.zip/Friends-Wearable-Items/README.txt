FRIENDS - WEARABLE ITEMS ONLY

Standalone parts extracted from Friendsie models previously downloaded locally.
This pack excludes complete character models, 44 body/clothing-body parts,
and 40 held items. Character heads and bodies are not included.

01-Eyewear: 1 pair of glasses (Green Round Frames)
02-Headwear: 28 head accessories
03-Back-Accessories: 41 back accessories
04-Footwear: 41 footwear parts
Total: 111 GLB files.

The GLB files were not regenerated or modified. They are byte-for-byte copies
of the existing standalone item files. Materials and embedded textures are
preserved. The files were checked for external texture/buffer dependencies;
none were found. Complete character rigs and animations are not included.
Fitting an item to another character may require changes to its scale,
position, or bone attachment.

manifest.json: original item ID, slot, package path, file size, and SHA-256.
SHA256SUMS.txt: integrity checksums for the GLB files in this pack.

This pack does not change the ownership or license terms of the original assets.
Game code, account/key files, maps, and server files are not included.
