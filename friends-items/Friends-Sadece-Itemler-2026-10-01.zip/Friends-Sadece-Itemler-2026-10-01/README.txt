FRIENDS — SADECE TAKILABILIR ITEMLER

Daha önce yerel olarak indirilmiş Friendsie modellerinden ayrılmış parçalar.
Tam karakter modelleri, 44 gövde/kıyafet-gövde parçası ve 40 adet elde tutulan
eşya bu pakete dahil değildir. Karakterin kafası/vücudu dahil edilmedi.

01-Gozluk: 1 gözlük (Green Round Frames)
02-Basliklar: 28 baş aksesuarı
03-Sirt-Aksesuarlari: 41 sırt aksesuarı
04-Ayakkabilar: 41 ayakkabı parçası
Toplam: 111 GLB dosyası.

Dosyalar yeniden üretilmedi veya değiştirilmedi; mevcut ayrılmış GLB dosyaları
birebir kopyalandı. Malzemeler ve gömülü dokular korunur. Harici doku/buffer
bağımlılığı bulunmadığı kontrol edilmiştir. Tam karakter rig/animasyonu yoktur.
Başka bir karaktere takarken boyut, konum ve kemik bağlantısı uyarlaması gerekebilir.

manifest.json: kaynak item kimliği, slot, paket yolu, dosya boyutu ve SHA-256.
SHA256SUMS.txt: paket içindeki GLB dosyalarının bütünlük değerleri.

Bu paket kaynak assetlerin mülkiyetini veya lisans koşullarını değiştirmez.
Oyun kodu, hesap/anahtar dosyaları, harita ve sunucu dosyaları dahil edilmedi.
